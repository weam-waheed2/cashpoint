<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateOffersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('offers', function (Blueprint $table) {
            $table->id();
            $table->string('offer_name')->nullable();
            $table->string('offer_points')->nullable();
            $table->bigInteger('UID')->default(0);
            $table->enum('status',['active', 'deactive'])->default('deactive');
            $table->string('offer_type')->nullable();
            $table->string('offer_link')->nullable();
            $table->json('offer_end')->default(json_encode([]));

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('offers');
    }
}
