<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Offer;


class CronJobController extends Controller
{
    public function UpdateCronJob(Request $request){
      $offersToUpdate = Offer::where('offer_end', '!=', '[]')->get();

      // Update offer_end to []
      foreach ($offersToUpdate as $offer) {
        $offer->offer_end = '[]';
        $offer->save();
      }
      return collect($offersToUpdate)->toJson();
    }
}
