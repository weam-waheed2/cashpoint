<?php

namespace App\Http\Controllers;

use App\Models\Offer;
use Illuminate\Http\Request;

class OffersController extends Controller
{
    public function List(Request $request){
        if($request->isMethod('post')){
            $this->Store($request);
            return back()->withInput();
        }
        $offers = Offer::all();
        return view('dashboard.offers.list',compact('offers'));
    }
    public function Store(Request $request){
        if(isset($request->ID)){
            $offer        = Offer::find($request->ID);
        }else{
            $offer        = new Offer();
        }
        $offer->UID                        = auth()->user()->id;
        $offer->offer_name                 = $request->offer_name;
        $offer->offer_points               = $request->offer_points;
        $offer->status                     = $request->status;
        $offer->offer_type                 = $request->offer_type;
        $offer->offer_link                 = $request->offer_link;
        $offer->save();
    }
    public function Delete($id){
        Offer::find($id)->delete();
        return back();
    }
}
