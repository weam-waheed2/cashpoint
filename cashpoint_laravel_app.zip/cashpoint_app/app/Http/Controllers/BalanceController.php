<?php

namespace App\Http\Controllers;

use App\Models\Balance;
use Illuminate\Http\Request;

class BalanceController extends Controller
{
    public function List(Request $request){
        if($request->isMethod('post')){
            $this->Store($request);
            return back()->withInput();
        }
        $balances = Balance::all();
        return view('dashboard.balance.list',compact('balances'));
    }
    public function Store(Request $request){
        if(isset($request->ID)){
            $balance        = Balance::find($request->ID);
        }else{
            $balance        = new Balance();
        }
        $balance->UID                        = auth()->user()->id;
        $balance->amount                     = $request->amount;
        $balance->UID_balance                = auth()->user()->balance;
        $balance->status                     = $request->status;
        $balance->save();
    }
    public function Delete($id){
        Balance::find($id)->delete();
        return back();
    }
}
