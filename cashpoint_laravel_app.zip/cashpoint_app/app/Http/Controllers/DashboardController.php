<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function Index(Request $request){
        return view('dashboard.home');
    }
}
