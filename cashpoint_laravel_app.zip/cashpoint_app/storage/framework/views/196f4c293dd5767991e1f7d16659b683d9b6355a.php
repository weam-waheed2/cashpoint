<div class="modal fade" id="<?php echo e(isset($balance) ? 'editBalanceModal_' . $balance->id : 'addBalanceModal'); ?>" tabindex="-1" role="dialog"
    aria-labelledby="addBalanceModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center">
                <h5 class="modal-title">
                    <?php echo e(isset($balance) ? 'تعديل سحب' : 'اضافة سحب'); ?>

                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e(isset($balance) ? $balance->id : ''); ?>" name="ID">
                <div class="modal-body" style="direction: rtl">
                    <div class="add-contact-box">
                        <div class="add-contact-content">
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-label d-flex">
                                        المبلغ المطلوب
                                    </label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" placeholder="المبلغ" name="amount" value="<?php echo e(isset($balance) ? $balance->amount : ''); ?>" required/>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label d-flex">
                                        الحاله
                                    </label>
                                    <div class="mb-3">
                                        <select class="form-control" name="status">
                                            <option disabled> الحاله</option>
                                            <option value="waiting" <?php echo e(isset($balance) && $balance->status == 'waiting' ? 'selected' : 'selected'); ?> >انتظار</option>
                                            <option value="complete" <?php echo e(isset($balance) && $balance->status == 'complete' ? 'selected' : ''); ?>>مكتمل</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="d-flex gap-6 m-0">
                        <button id="btn-add" class="btn btn-success rounded-pill" type="submit">
                            <?php echo e(isset($balance) ? 'تعديل' : 'اضافة'); ?>  
                        </button>
                        <button class="btn bg-danger-subtle text-danger rounded-pill" data-bs-dismiss="modal">
                            إغلاق
                        </button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\cashpoint_app\resources\views/dashboard/balance/modals/add.blade.php ENDPATH**/ ?>