<div class="modal fade" id="<?php echo e(isset($offer) ? 'editOfferModal_' . $offer->id : 'addOfferModal'); ?>" tabindex="-1" role="dialog"
    aria-labelledby="addOfferModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center">
                <h5 class="modal-title">
                    <?php echo e(isset($offer) ? 'تعديل عرض' : 'اضافة عرض'); ?>

                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>
            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" value="<?php echo e(isset($offer) ? $offer->id : ''); ?>" name="ID">
                <div class="modal-body" style="direction: rtl">
                    <div class="add-contact-box">
                        <div class="add-contact-content">
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-label d-flex">
                                        اسم العرض   
                                    </label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" placeholder="اسم العرض" name="offer_name" value="<?php echo e(isset($offer) ? $offer->offer_name : ''); ?>" required/>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label d-flex">
                                        النقاط
                                    </label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" placeholder="النقاط" name="offer_points" value="<?php echo e(isset($offer) ? $offer->offer_points : ''); ?>" required/>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <label class="form-label d-flex">
                                        الحاله
                                    </label>
                                    <div class="mb-3">
                                        <select class="form-control" name="status">
                                            <option disabled> الحاله</option>
                                            <option value="active" <?php echo e(isset($offer) && $offer->status == 'active' ? 'selected' : ''); ?> > نشيط</option>
                                            <option value="deactive" <?php echo e(isset($offer) && $offer->status == 'deactive' ? 'selected' : 'selected'); ?> >غير نشيط</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label d-flex">
                                        نوع العرض
                                    </label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" placeholder=" نوع العرض" name="offer_type" value="<?php echo e(isset($offer) ? $offer->offer_type : ''); ?>" required/>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label d-flex">
                                        رابط العرض
                                    </label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" placeholder="رابط العرض" name="offer_link" value="<?php echo e(isset($offer) ? $offer->offer_link : ''); ?>" required/>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="d-flex gap-6 m-0">
                        <button id="btn-add" class="btn btn-success rounded-pill" type="submit">
                            <?php echo e(isset($offer) ? 'تعديل' : 'اضافة'); ?>  
                        </button>
                        <button class="btn bg-danger-subtle text-danger rounded-pill" data-bs-dismiss="modal">
                            إغلاق
                        </button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\cashpoint_app\resources\views/dashboard/offers/modals/add.blade.php ENDPATH**/ ?>