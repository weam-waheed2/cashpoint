<div class="modal fade" id="{{ isset($gift) ? 'editGiftModal_' . $gift->id : 'addGiftModal' }}" tabindex="-1" role="dialog"
    aria-labelledby="addGiftModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center">
                <h5 class="modal-title">
                    {{ isset($gift) ? 'تعديل هديه' : 'اضافة هديه' }}
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>
            <form method="POST">
                @csrf
                <input type="hidden" value="{{ isset($gift) ? $gift->id : '' }}" name="ID">
                <div class="modal-body" style="direction: rtl">
                    <div class="add-contact-box">
                        <div class="add-contact-content">
                            
                            <div class="row">
                                <div class="col-md-12">
                                    <label class="form-label d-flex">
                                        النقاط
                                    </label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" placeholder="النقاط" name="points" value="{{ isset($gift) ? $gift->points : \App\Models\Settings::get('daily_gift_points') }}" required/>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="d-flex gap-6 m-0">
                        <button id="btn-add" class="btn btn-success rounded-pill" type="submit">
                            {{ isset($gift) ? 'تعديل' : 'اضافة' }}  
                        </button>
                        <button class="btn bg-danger-subtle text-danger rounded-pill" data-bs-dismiss="modal">
                            إغلاق
                        </button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>