<div class="modal fade" id="{{ isset($balance) ? 'editBalanceModal_' . $balance->id : 'addBalanceModal' }}" tabindex="-1" role="dialog"
    aria-labelledby="addBalanceModalTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header d-flex align-items-center">
                <h5 class="modal-title">
                    {{ isset($balance) ? 'تعديل سحب' : 'اضافة سحب' }}
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"
                    aria-label="Close"></button>
            </div>
            <form method="POST">
                @csrf
                <input type="hidden" value="{{ isset($balance) ? $balance->id : '' }}" name="ID">
                <div class="modal-body" style="direction: rtl">
                    <div class="add-contact-box">
                        <div class="add-contact-content">
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <label class="form-label d-flex">
                                        المبلغ المطلوب
                                    </label>
                                    <div class="mb-3">
                                        <input type="text" class="form-control" placeholder="المبلغ" name="amount" value="{{ isset($balance) ? $balance->amount : '' }}" required/>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label d-flex">
                                        الحاله
                                    </label>
                                    <div class="mb-3">
                                        <select class="form-control" name="status">
                                            <option disabled> الحاله</option>
                                            <option value="waiting" {{isset($balance) && $balance->status == 'waiting' ? 'selected' : 'selected'}} >انتظار</option>
                                            <option value="complete" {{isset($balance) && $balance->status == 'complete' ? 'selected' : ''}}>مكتمل</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <div class="d-flex gap-6 m-0">
                        <button id="btn-add" class="btn btn-success rounded-pill" type="submit">
                            {{ isset($balance) ? 'تعديل' : 'اضافة' }}  
                        </button>
                        <button class="btn bg-danger-subtle text-danger rounded-pill" data-bs-dismiss="modal">
                            إغلاق
                        </button>
                    </div>

                </div>
            </form>
        </div>
    </div>
</div>