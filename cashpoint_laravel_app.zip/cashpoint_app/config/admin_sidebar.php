<?php
return array(
    array(
        'name'          => 'لوحة التحكم',
        'icon'          => 'ti ti-home',
        'url'           => 'home',
    ),
    array(
        'name'          => 'المستخدمين',
        'icon'          => 'ti ti-user',
        'url'           => 'home/users',
    ),
    array(
        'name'          => 'العروض',
        'icon'          => 'ti ti-menu',
        'url'           => 'home/offers',
    ),
    array(
        'name'          => 'الهدايا اليومية',
        'icon'          => 'ti ti-id-badge',
        'url'           => 'home/daily_gifts',
    ),
    array(
        'name'          => 'السحب',
        'icon'          => 'ti ti-clipboard',
        'url'           => 'home/balance',
    ),
    array(
        'name'          => 'التقارير',
        'icon'          => 'ti ti-files',
        'url'           => 'home/reports',
    ),
    array(
        'name'          => 'الاعدادات',
        'icon'          => 'ti ti-id-badge',
        'url'           => 'home/settings',
    ),
);